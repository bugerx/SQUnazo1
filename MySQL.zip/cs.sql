/*
 Navicat Premium Data Transfer

 Target Server Type    : MySQL
 Target Server Version : 50535
 File Encoding         : 65001

 Date: 30/11/2019 12:09:23
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for cs
-- ----------------------------
DROP TABLE IF EXISTS `cs`;
CREATE TABLE `cs`  (
  `uid` int(5) UNSIGNED NOT NULL AUTO_INCREMENT,
  `studentId` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `group` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `departmentName` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `majorName` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `className` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `QQ` bigint(11) UNSIGNED NOT NULL,
  `phone` bigint(11) UNSIGNED NULL DEFAULT NULL,
  `updataTime` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`uid`, `studentId`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 10463 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

SET FOREIGN_KEY_CHECKS = 1;
